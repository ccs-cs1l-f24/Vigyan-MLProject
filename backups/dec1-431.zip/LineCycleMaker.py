def LineGraph(n):
    pass